
class Rectangle {
    constructor(height, width){
        this.height = height;
        this.width = width;
    }

    calcArea(){
        return this.height * this.width;
    }
}

const square = new Rectangle (10, 10);

square.calcArea();

class ColoredRectangle extends Rectangle {
    constructor (height, width, bgColor){
        super(height, width);
        this.bgColor = bgColor; 
        
    }
    showProps(){
        console.log(`${this.bgColor}`);
    }
}

const redRectangle = new ColoredRectangle(10, 10, 'red');
redRectangle.calcArea();

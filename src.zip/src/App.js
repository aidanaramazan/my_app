import React, { useState, useEffect } from 'react';
import './App.css';
import deepai from 'deepai';

const App = () => {
  const [formulas, setFormulas] = useState([]);
  const [inputValue, setInputValue] = useState('');

  useEffect(() => {
    deepai.setApiKey('ec0d3f93-71f8-4051-aa16-16c3f6e16621');

    const fetchData = async () => {
      var resp = await deepai.callStandardApi('anime-world-generator', {
        text: 'YOUR_TEXT_URL',
      });
      console.log(resp);
    };

    fetchData();
  }, []);

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    setFormulas([...formulas, inputValue]);
    setInputValue('');
  };

  const handleRemoveFormula = (index) => {
    const updatedFormulas = [...formulas];
    updatedFormulas.splice(index, 1);
    setFormulas(updatedFormulas);
  };

  return (
    <div>
      <h2 className='header'>Science Formulas Visualization</h2>
      <form onSubmit={handleFormSubmit}>
        <input
          type='text'
          placeholder='Enter a formula'
          className='input'
          value={inputValue}
          onChange={handleInputChange}
        />
        <button className='btn' type='submit'>
          Submit
        </button>
      </form>
      <div>
        {formulas.map((formula, index) => (
          <div className='formulas-container' key={index}>
            <p>{formula}</p>
            <button className='btn2' onClick={() => handleRemoveFormula(index)}>
              Remove
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;

import './App.css';

function Header() {
    return (
        <div className="App">
            <p>Its header</p>
            <a>Home</a>
        </div>
    );
}

export default Header;
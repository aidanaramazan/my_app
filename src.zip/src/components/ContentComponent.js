//several components in one file;

function Home(){
    return(
        <p>Its Home component</p>
    )
}


function About(){
    return(
        <p>Its About component</p>
    )
}



export   {Home, About} ;
import React from 'react'; // Add this line to import React
import { render } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
});
